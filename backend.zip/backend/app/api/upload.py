from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
import json
import asyncio
from app.services.ingestion_service import detect_file_type, load_tabular
from app.services.analysis_service import analyze_tabular
from app.services.session_service import create_session, save_data_context, add_to_history
from app.services.session_service import save_file_bytes

router = APIRouter()

@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    async def event_generator():
        # Étape 1 : Lecture et détection du format
        yield json.dumps({
            "status": "processing",
            "step": 1,
            "message": "Lecture et détection du format du fichier..."
        }) + "\n"
        await asyncio.sleep(0.05)

        try:
            file_bytes = await file.read()
            filename = file.filename
            file_type = detect_file_type(filename)
        except Exception as e:
            yield json.dumps({
                "status": "error",
                "message": "Une erreur est survenue lors de la lecture du fichier.",
                "technical": str(e)
            }) + "\n"
            return

        if file_type == "unsupported":
            yield json.dumps({
                "status": "error",
                "message": "Format non supporté. Utilisez CSV, Excel ou PDF.",
                "technical": "Unsupported file format"
            }) + "\n"
            return

        if file_type == "tabular":
            # Étape 2 : Analyse structurelle
            yield json.dumps({
                "status": "processing",
                "step": 2,
                "message": "Analyse structurelle et calcul des statistiques..."
            }) + "\n"
            await asyncio.sleep(0.05)

            try:
                check = load_tabular(file_bytes, filename)
                if check["status"] == "error":
                    yield json.dumps({
                        "status": "error",
                        "message": "Votre fichier n'a pas pu être lu. Vérifiez qu'il n'est pas corrompu.",
                        "technical": check.get("message", "Error loading tabular data")
                    }) + "\n"
                    return

            except Exception as e:
                yield json.dumps({
                    "status": "error",
                    "message": "Erreur d'analyse des données tabulaires.",
                    "technical": str(e)
                }) + "\n"
                return

            # Étape 3 : Interprétation IA
            yield json.dumps({
                "status": "processing",
                "step": 3,
                "message": "Génération de l'interprétation intelligente par l'IA..."
            }) + "\n"
            await asyncio.sleep(0.05)

            try:
                result = await analyze_tabular(file_bytes, filename)
                if result.get("status") == "error":
                    yield json.dumps({
                        "status": "error",
                        "message": "Une erreur est survenue lors de l'analyse des données.",
                        "technical": result.get("message", "Unknown error in analysis")
                    }) + "\n"
                    return

                # Étape 4 : Initialisation de la session
                yield json.dumps({
                    "status": "processing",
                    "step": 4,
                    "message": "Finalisation et initialisation de la session..."
                }) + "\n"
                await asyncio.sleep(0.05)

                session_id = create_session()
                save_data_context(session_id, result["profile"], result["stats"], filename)
                from app.services.session_service import save_initial_analysis
                save_initial_analysis(session_id, result["interpretation"])
                save_file_bytes(session_id, file_bytes, filename)
                add_to_history(session_id, "model", result["interpretation"])

                # L'ancien dashboard HTML n'est plus généré ici.
                # Il sera généré à la volée en JSON par /api/dashboard/data/{session_id}

                yield json.dumps({
                    "status": "completed",
                    "data": {
                        "type": "tabular_analyzed",
                        "session_id": session_id,
                        "profile": result["profile"],
                        "stats": result["stats"],
                        "interpretation": result["interpretation"]
                    }
                }) + "\n"
            except Exception as e:
                yield json.dumps({
                    "status": "error",
                    "message": "Erreur lors du traitement IA ou de la création de session.",
                    "technical": str(e)
                }) + "\n"
                return

        if file_type == "document":
            from app.services.rag_service import index_document, summarize_document
            from app.services.gemini_service import ask_gemini
            from app.services.session_service import set_session_type

            # Étape 2 : Découpage et Indexation
            yield json.dumps({
                "status": "processing",
                "step": 2,
                "message": "Découpage et indexation vectorielle du document..."
            }) + "\n"
            await asyncio.sleep(0.05)

            try:
                session_id = create_session()
                set_session_type(session_id, "document")
                index_result = index_document(session_id, file_bytes, filename)

                if index_result["status"] == "error":
                    yield json.dumps({
                        "status": "error",
                        "message": "Le document n'a pas pu être indexé. Vérifiez qu'il contient du texte lisible.",
                        "technical": index_result.get("message", "Indexing error")
                    }) + "\n"
                    return
            except Exception as e:
                yield json.dumps({
                    "status": "error",
                    "message": "Erreur lors de l'indexation du document.",
                    "technical": str(e)
                }) + "\n"
                return

            # Étape 3 : Analyse et résumé IA
            yield json.dumps({
                "status": "processing",
                "step": 3,
                "message": "Analyse et génération du résumé par l'IA..."
            }) + "\n"
            await asyncio.sleep(0.05)

            try:
                raw_context = summarize_document(session_id)
                summary_prompt = f"""
                Voici le début d'un document :

                {raw_context}

                Rédige un résumé structuré, naturel et fluide en français.
                Ne commence JAMAIS le résumé par une introduction ou des salutations (par exemple : "Bonjour", "En tant qu'expert...", "Voici le résumé..."). Rentre directement dans le vif du sujet.

                Organise ta réponse sous cette forme :

                ### 1. THÈMES PRINCIPAUX
                [Présente les grands thèmes abordés sous forme de liste à puces naturelle]

                ### 2. POINTS CLÉS
                [Présente 3 à 5 informations importantes sous forme de liste à puces naturelle]

                ### 3. PROPOSITIONS
                [Propose 3 questions ou analyses pertinentes suggérées par ce document]
                """
                summary = ask_gemini(summary_prompt)
                add_to_history(session_id, "model", summary)

                # Étape 4 : Finalisation de la session
                yield json.dumps({
                    "status": "processing",
                    "step": 4,
                    "message": "Finalisation et initialisation de la session..."
                }) + "\n"
                await asyncio.sleep(0.05)

                yield json.dumps({
                    "status": "completed",
                    "data": {
                        "type": "document_analyzed",
                        "session_id": session_id,
                        "filename": filename,
                        "chunks_indexed": index_result["chunks_indexed"],
                        "summary": summary
                    }
                }) + "\n"
            except Exception as e:
                yield json.dumps({
                    "status": "error",
                    "message": "Erreur lors de la génération du résumé par l'IA.",
                    "technical": str(e)
                }) + "\n"
                return

    return StreamingResponse(event_generator(), media_type="application/x-ndjson")
